console.log(">> Common script is loaded.");
//# sourceMappingURL=common.aefcfcca.js.map